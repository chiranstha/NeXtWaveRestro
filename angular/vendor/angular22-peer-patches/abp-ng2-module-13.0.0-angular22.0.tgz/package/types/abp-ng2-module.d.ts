import * as i0 from '@angular/core';
import { Injector } from '@angular/core';
import { HttpClient, HttpResponse, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

declare class AbpModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AbpModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AbpModule>;
}

declare class TokenService {
    getToken(): string;
    getTokenCookieName(): string;
    clearToken(): void;
    setToken(authToken: string, expireDate?: Date): void;
    getRefreshToken(): string;
    getRefreshTokenCookieName(): string;
    clearRefreshToken(): void;
    setRefreshToken(refreshToken: string, expireDate?: Date): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TokenService>;
}

declare class PermissionCheckerService {
    isGranted(permissionName: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionCheckerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionCheckerService>;
}

declare class FeatureCheckerService {
    get(featureName: string): abp.features.IFeature;
    getValue(featureName: string): string;
    isEnabled(featureName: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureCheckerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeatureCheckerService>;
}

declare class LocalizationService {
    get languages(): abp.localization.ILanguageInfo[];
    get currentLanguage(): abp.localization.ILanguageInfo;
    localize(key: string, sourceName: string): string;
    getSource(sourceName: string): (...key: string[]) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalizationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalizationService>;
}

declare class LogService {
    debug(logObject?: any): void;
    info(logObject?: any): void;
    warn(logObject?: any): void;
    error(logObject?: any): void;
    fatal(logObject?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LogService>;
}

declare class MessageService {
    info(message: string, title?: string, options?: any): any;
    success(message: string, title?: string, options?: any): any;
    warn(message: string, title?: string, options?: any): any;
    error(message: string, title?: string, options?: any): any;
    confirm(message: string, title?: string, callback?: (result: boolean, info?: any) => void, options?: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageService>;
}

declare class AbpMultiTenancyService {
    get isEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpMultiTenancyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbpMultiTenancyService>;
}

declare class NotifyService {
    info(message: string, title?: string, options?: any): void;
    success(message: string, title?: string, options?: any): void;
    warn(message: string, title?: string, options?: any): void;
    error(message: string, title?: string, options?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotifyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotifyService>;
}

declare class AbpSessionService {
    get userId(): number | undefined;
    get tenantId(): number | undefined;
    get impersonatorUserId(): number | undefined;
    get impersonatorTenantId(): number | undefined;
    get multiTenancySide(): abp.multiTenancy.sides;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpSessionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbpSessionService>;
}

declare class SettingService {
    get(name: string): string;
    getBoolean(name: string): boolean;
    getInt(name: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SettingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SettingService>;
}

declare class UtilsService {
    getCookieValue(key: string): string;
    setCookieValue(key: string, value: string, expireDate?: Date, path?: string, domain?: string, attributes?: any): void;
    deleteCookie(key: string, path?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UtilsService>;
}

declare class AbpUserConfigurationService {
    private _http;
    constructor(_http: HttpClient);
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpUserConfigurationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbpUserConfigurationService>;
}

interface IValidationErrorInfo {
    message: string;
    members: string[];
}
interface IErrorInfo {
    code: number;
    message: string;
    details: string;
    validationErrors: IValidationErrorInfo[];
}
interface IAjaxResponse {
    success: boolean;
    result?: any;
    targetUrl?: string;
    error?: IErrorInfo;
    unAuthorizedRequest: boolean;
    __abp: boolean;
}

declare class AbpHttpConfigurationService {
    private _messageService;
    private _logService;
    constructor(_messageService: MessageService, _logService: LogService);
    forceHeaderCookieWrite: boolean;
    localizationCultureHeaderName: string;
    defaultError: IErrorInfo;
    defaultError401: IErrorInfo;
    defaultError403: IErrorInfo;
    defaultError404: IErrorInfo;
    logError(error: IErrorInfo): void;
    showError(error: IErrorInfo): any;
    handleTargetUrl(targetUrl: string): void;
    handleUnAuthorizedRequest(messagePromise: any, targetUrl?: string): void;
    handleNonAbpErrorResponse(response: HttpResponse<any>): void;
    handleAbpResponse(response: HttpResponse<any>, ajaxResponse: IAjaxResponse): HttpResponse<any>;
    getAbpAjaxResponseOrNull(response: HttpResponse<any>): IAjaxResponse | null;
    handleResponse(response: HttpResponse<any>): HttpResponse<any>;
    blobToText(blob: any): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpHttpConfigurationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbpHttpConfigurationService>;
}

declare class AbpHttpInterceptor implements HttpInterceptor {
    private _injector;
    protected configuration: AbpHttpConfigurationService;
    private _tokenService;
    private _utilsService;
    private _logService;
    constructor(configuration: AbpHttpConfigurationService, _injector: Injector);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    protected tryGetRefreshTokenService(): Observable<boolean>;
    private isRefreshing;
    private refreshTokenSubject;
    private tryAuthWithRefreshToken;
    protected normalizeRequestHeaders(request: HttpRequest<any>): HttpRequest<any>;
    protected addXRequestedWithHeader(headers: HttpHeaders): HttpHeaders;
    protected addAspNetCoreCultureHeader(headers: HttpHeaders): HttpHeaders;
    protected addAcceptLanguageHeader(headers: HttpHeaders): HttpHeaders;
    protected addTenantIdHeader(headers: HttpHeaders): HttpHeaders;
    protected addAuthorizationHeaders(headers: HttpHeaders): HttpHeaders;
    protected handleSuccessResponse(event: HttpEvent<any>): Observable<HttpEvent<any>>;
    protected handleErrorResponse(error: any): Observable<never>;
    private itemExists;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbpHttpInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbpHttpInterceptor>;
}

declare abstract class RefreshTokenService {
    /**
     * Try to authenticate with refresh token and return if auth succeed
     */
    abstract tryAuthWithRefreshToken(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RefreshTokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RefreshTokenService>;
}

export { AbpHttpConfigurationService, AbpHttpInterceptor, AbpModule, AbpMultiTenancyService, AbpSessionService, AbpUserConfigurationService, FeatureCheckerService, LocalizationService, LogService, MessageService, NotifyService, PermissionCheckerService, RefreshTokenService, SettingService, TokenService, UtilsService };
export type { IAjaxResponse, IErrorInfo, IValidationErrorInfo };
