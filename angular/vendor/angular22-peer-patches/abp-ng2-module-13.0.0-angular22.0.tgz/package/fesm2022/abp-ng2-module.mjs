import * as i0 from '@angular/core';
import { NgModule, Injectable } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, of, BehaviorSubject, throwError } from 'rxjs';
import { catchError, switchMap, filter, take, map } from 'rxjs/operators';

class AbpModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.2", ngImport: i0, type: AbpModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: []
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class TokenService {
    getToken() {
        return abp.auth.getToken();
    }
    getTokenCookieName() {
        return abp.auth.tokenCookieName;
    }
    clearToken() {
        abp.auth.clearToken();
    }
    setToken(authToken, expireDate) {
        abp.auth.setToken(authToken, expireDate);
    }
    //refresh token
    getRefreshToken() {
        return abp.auth.getRefreshToken();
    }
    getRefreshTokenCookieName() {
        return abp.auth.refreshTokenCookieName;
    }
    clearRefreshToken() {
        abp.auth.clearRefreshToken();
    }
    setRefreshToken(refreshToken, expireDate) {
        abp.auth.setRefreshToken(refreshToken, expireDate);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: TokenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: TokenService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: TokenService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class PermissionCheckerService {
    isGranted(permissionName) {
        return abp.auth.isGranted(permissionName);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: PermissionCheckerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: PermissionCheckerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: PermissionCheckerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class FeatureCheckerService {
    get(featureName) {
        return abp.features.get(featureName);
    }
    getValue(featureName) {
        return abp.features.getValue(featureName);
    }
    isEnabled(featureName) {
        return abp.features.isEnabled(featureName);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: FeatureCheckerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: FeatureCheckerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: FeatureCheckerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class LocalizationService {
    get languages() {
        return abp.localization.languages;
    }
    get currentLanguage() {
        return abp.localization.currentLanguage;
    }
    localize(key, sourceName) {
        return abp.localization.localize(key, sourceName);
    }
    getSource(sourceName) {
        return abp.localization.getSource(sourceName);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LocalizationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LocalizationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LocalizationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class LogService {
    debug(logObject) {
        abp.log.debug(logObject);
    }
    info(logObject) {
        abp.log.info(logObject);
    }
    warn(logObject) {
        abp.log.warn(logObject);
    }
    error(logObject) {
        abp.log.error(logObject);
    }
    fatal(logObject) {
        abp.log.fatal(logObject);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: LogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class MessageService {
    info(message, title, options) {
        return abp.message.info(message, title, options);
    }
    success(message, title, options) {
        return abp.message.success(message, title, options);
    }
    warn(message, title, options) {
        return abp.message.warn(message, title, options);
    }
    error(message, title, options) {
        return abp.message.error(message, title, options);
    }
    confirm(message, title, callback, options) {
        return abp.message.confirm(message, title, callback, options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: MessageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: MessageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: MessageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class AbpMultiTenancyService {
    get isEnabled() {
        return abp.multiTenancy.isEnabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpMultiTenancyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpMultiTenancyService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpMultiTenancyService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class NotifyService {
    info(message, title, options) {
        abp.notify.info(message, title, options);
    }
    success(message, title, options) {
        abp.notify.success(message, title, options);
    }
    warn(message, title, options) {
        abp.notify.warn(message, title, options);
    }
    error(message, title, options) {
        abp.notify.error(message, title, options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: NotifyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: NotifyService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: NotifyService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class AbpSessionService {
    get userId() {
        return abp.session.userId;
    }
    get tenantId() {
        return abp.session.tenantId;
    }
    get impersonatorUserId() {
        return abp.session.impersonatorUserId;
    }
    get impersonatorTenantId() {
        return abp.session.impersonatorTenantId;
    }
    get multiTenancySide() {
        return abp.session.multiTenancySide;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpSessionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpSessionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpSessionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class SettingService {
    get(name) {
        return abp.setting.get(name);
    }
    getBoolean(name) {
        return abp.setting.getBoolean(name);
    }
    getInt(name) {
        return abp.setting.getInt(name);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: SettingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: SettingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: SettingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class UtilsService {
    getCookieValue(key) {
        return abp.utils.getCookieValue(key);
    }
    setCookieValue(key, value, expireDate, path, domain, attributes) {
        abp.utils.setCookieValue(key, value, expireDate, path, domain, attributes);
    }
    deleteCookie(key, path) {
        abp.utils.deleteCookie(key, path);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: UtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: UtilsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: UtilsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

///<reference path="../../../../../node_modules/abp-web-resources/Abp/Framework/scripts/abp.d.ts"/>
class AbpUserConfigurationService {
    _http;
    constructor(_http) {
        this._http = _http;
    }
    initialize() {
        this._http.get('/AbpUserConfiguration/GetAll')
            .subscribe(result => {
            jQuery.extend(true, abp, JSON.parse(JSON.stringify(result)));
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpUserConfigurationService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpUserConfigurationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpUserConfigurationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

class RefreshTokenService {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: RefreshTokenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: RefreshTokenService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: RefreshTokenService, decorators: [{
            type: Injectable
        }] });

class AbpHttpConfigurationService {
    _messageService;
    _logService;
    constructor(_messageService, _logService) {
        this._messageService = _messageService;
        this._logService = _logService;
    }
    forceHeaderCookieWrite = true;
    localizationCultureHeaderName = '.AspNetCore.Culture';
    defaultError = {
        message: 'An error has occurred!',
        details: 'Error details were not sent by server.'
    };
    defaultError401 = {
        message: 'You are not authenticated!',
        details: 'You should be authenticated (sign in) in order to perform this operation.'
    };
    defaultError403 = {
        message: 'You are not authorized!',
        details: 'You are not allowed to perform this operation.'
    };
    defaultError404 = {
        message: 'Resource not found!',
        details: 'The resource requested could not be found on the server.'
    };
    logError(error) {
        this._logService.error(error);
    }
    showError(error) {
        if (error.details) {
            return this._messageService.error(error.details, error.message || this.defaultError.message);
        }
        else {
            return this._messageService.error(error.message || this.defaultError.message);
        }
    }
    handleTargetUrl(targetUrl) {
        if (!targetUrl) {
            location.href = '/';
        }
        else {
            location.href = targetUrl;
        }
    }
    handleUnAuthorizedRequest(messagePromise, targetUrl) {
        const self = this;
        if (messagePromise) {
            messagePromise.done(() => {
                this.handleTargetUrl(targetUrl || '/');
            });
        }
        else {
            self.handleTargetUrl(targetUrl || '/');
        }
    }
    handleNonAbpErrorResponse(response) {
        const self = this;
        switch (response.status) {
            case 401:
                self.handleUnAuthorizedRequest(self.showError(self.defaultError401), '/');
                break;
            case 403:
                self.showError(self.defaultError403);
                break;
            case 404:
                self.showError(self.defaultError404);
                break;
            default:
                self.showError(self.defaultError);
                break;
        }
    }
    handleAbpResponse(response, ajaxResponse) {
        var newResponse;
        if (ajaxResponse.success) {
            newResponse = response.clone({
                body: ajaxResponse.result
            });
            if (ajaxResponse.targetUrl) {
                this.handleTargetUrl(ajaxResponse.targetUrl);
                ;
            }
        }
        else {
            newResponse = response.clone({
                body: ajaxResponse.result
            });
            if (!ajaxResponse.error) {
                ajaxResponse.error = this.defaultError;
            }
            this.logError(ajaxResponse.error);
            this.showError(ajaxResponse.error);
            if (response.status === 401) {
                this.handleUnAuthorizedRequest(null, ajaxResponse.targetUrl);
            }
        }
        return newResponse;
    }
    getAbpAjaxResponseOrNull(response) {
        if (!response || !response.headers) {
            return null;
        }
        var contentType = response.headers.get('Content-Type');
        if (!contentType) {
            this._logService.warn('Content-Type is not sent!');
            return null;
        }
        if (contentType.indexOf("application/json") < 0) {
            this._logService.warn('Content-Type is not application/json: ' + contentType);
            return null;
        }
        var responseObj = JSON.parse(JSON.stringify(response.body));
        if (!responseObj.__abp) {
            return null;
        }
        return responseObj;
    }
    handleResponse(response) {
        var ajaxResponse = this.getAbpAjaxResponseOrNull(response);
        if (ajaxResponse == null) {
            return response;
        }
        return this.handleAbpResponse(response, ajaxResponse);
    }
    blobToText(blob) {
        return new Observable((observer) => {
            if (!blob) {
                observer.next("");
                observer.complete();
            }
            else {
                let reader = new FileReader();
                reader.onload = function () {
                    observer.next(this.result);
                    observer.complete();
                };
                reader.readAsText(blob);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpConfigurationService, deps: [{ token: MessageService }, { token: LogService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpConfigurationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpConfigurationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: MessageService }, { type: LogService }] });

class AbpHttpInterceptor {
    _injector;
    configuration;
    _tokenService = new TokenService();
    _utilsService = new UtilsService();
    _logService = new LogService();
    constructor(configuration, _injector) {
        this._injector = _injector;
        this.configuration = configuration;
    }
    intercept(request, next) {
        var modifiedRequest = this.normalizeRequestHeaders(request);
        return next.handle(modifiedRequest)
            .pipe(catchError(error => {
            if (error instanceof HttpErrorResponse && error.status === 401) {
                return this.tryAuthWithRefreshToken(request, next, error);
            }
            else {
                return this.handleErrorResponse(error);
            }
        }), switchMap((event) => {
            return this.handleSuccessResponse(event);
        }));
    }
    tryGetRefreshTokenService() {
        var _refreshTokenService = this._injector.get(RefreshTokenService, null);
        if (_refreshTokenService) {
            return _refreshTokenService.tryAuthWithRefreshToken();
        }
        return of(false);
    }
    isRefreshing = false;
    refreshTokenSubject = new BehaviorSubject(null);
    tryAuthWithRefreshToken(request, next, error) {
        if (!this.isRefreshing) {
            this.isRefreshing = true;
            this.refreshTokenSubject.next(null);
            return this.tryGetRefreshTokenService().pipe(switchMap((authResult) => {
                this.isRefreshing = false;
                if (authResult) {
                    this.refreshTokenSubject.next(authResult);
                    let modifiedRequest = this.normalizeRequestHeaders(request);
                    return next.handle(modifiedRequest);
                }
                else {
                    return this.handleErrorResponse(error);
                }
            }));
        }
        else {
            return this.refreshTokenSubject.pipe(filter(authResult => authResult != null), take(1), switchMap(authResult => {
                let modifiedRequest = this.normalizeRequestHeaders(request);
                return next.handle(modifiedRequest);
            }));
        }
    }
    normalizeRequestHeaders(request) {
        var modifiedHeaders = new HttpHeaders();
        modifiedHeaders = request.headers.set("Pragma", "no-cache")
            .set("Cache-Control", "no-cache")
            .set("Expires", "Sat, 01 Jan 2000 00:00:00 GMT");
        modifiedHeaders = this.addXRequestedWithHeader(modifiedHeaders);
        modifiedHeaders = this.addAuthorizationHeaders(modifiedHeaders);
        modifiedHeaders = this.addAspNetCoreCultureHeader(modifiedHeaders);
        modifiedHeaders = this.addAcceptLanguageHeader(modifiedHeaders);
        modifiedHeaders = this.addTenantIdHeader(modifiedHeaders);
        return request.clone({
            headers: modifiedHeaders
        });
    }
    addXRequestedWithHeader(headers) {
        if (headers) {
            headers = headers.set('X-Requested-With', 'XMLHttpRequest');
        }
        return headers;
    }
    addAspNetCoreCultureHeader(headers) {
        let cookieLangValue = this._utilsService.getCookieValue("Abp.Localization.CultureName");
        if (cookieLangValue && headers && (!headers.has(this.configuration.localizationCultureHeaderName) || this.configuration.forceHeaderCookieWrite)) {
            headers = headers.set(this.configuration.localizationCultureHeaderName, cookieLangValue);
        }
        return headers;
    }
    addAcceptLanguageHeader(headers) {
        let cookieLangValue = this._utilsService.getCookieValue("Abp.Localization.CultureName");
        if (cookieLangValue && headers && !headers.has('Accept-Language')) {
            headers = headers.set('Accept-Language', cookieLangValue);
        }
        return headers;
    }
    addTenantIdHeader(headers) {
        let cookieTenantIdValue = this._utilsService.getCookieValue(abp.multiTenancy.tenantIdCookieName);
        if (cookieTenantIdValue && headers && !headers.has(abp.multiTenancy.tenantIdCookieName)) {
            headers = headers.set(abp.multiTenancy.tenantIdCookieName, cookieTenantIdValue);
        }
        return headers;
    }
    addAuthorizationHeaders(headers) {
        let authorizationHeaders = headers ? headers.getAll('Authorization') : null;
        if (!authorizationHeaders) {
            authorizationHeaders = [];
        }
        if (!this.itemExists(authorizationHeaders, (item) => item.indexOf('Bearer ') == 0)) {
            let token = this._tokenService.getToken();
            if (headers && token) {
                headers = headers.set('Authorization', 'Bearer ' + token);
            }
        }
        return headers;
    }
    handleSuccessResponse(event) {
        var self = this;
        if (event instanceof HttpResponse) {
            if (event.body instanceof Blob && event.body.type && event.body.type.indexOf("application/json") >= 0) {
                return self.configuration.blobToText(event.body).pipe(map(json => {
                    const responseBody = json == "null" ? {} : JSON.parse(json);
                    var modifiedResponse = self.configuration.handleResponse(event.clone({
                        body: responseBody
                    }));
                    return modifiedResponse.clone({
                        body: new Blob([JSON.stringify(modifiedResponse.body)], { type: 'application/json' })
                    });
                }));
            }
        }
        return of(event);
    }
    handleErrorResponse(error) {
        if (!(error.error instanceof Blob)) {
            return throwError(error);
        }
        return this.configuration.blobToText(error.error).pipe(switchMap((json) => {
            const errorBody = (json == "" || json == "null") ? {} : JSON.parse(json);
            const errorResponse = new HttpResponse({
                headers: error.headers,
                status: error.status,
                body: errorBody
            });
            var ajaxResponse = this.configuration.getAbpAjaxResponseOrNull(errorResponse);
            if (ajaxResponse != null) {
                this.configuration.handleAbpResponse(errorResponse, ajaxResponse);
            }
            else {
                this.configuration.handleNonAbpErrorResponse(errorResponse);
            }
            return throwError(error);
        }));
    }
    itemExists(items, predicate) {
        for (let i = 0; i < items.length; i++) {
            if (predicate(items[i])) {
                return true;
            }
        }
        return false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpInterceptor, deps: [{ token: AbpHttpConfigurationService }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpInterceptor });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.2", ngImport: i0, type: AbpHttpInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: AbpHttpConfigurationService }, { type: i0.Injector }] });

/*
 * Public API Surface of abp-ng2-module
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AbpHttpConfigurationService, AbpHttpInterceptor, AbpModule, AbpMultiTenancyService, AbpSessionService, AbpUserConfigurationService, FeatureCheckerService, LocalizationService, LogService, MessageService, NotifyService, PermissionCheckerService, RefreshTokenService, SettingService, TokenService, UtilsService };
//# sourceMappingURL=abp-ng2-module.mjs.map
