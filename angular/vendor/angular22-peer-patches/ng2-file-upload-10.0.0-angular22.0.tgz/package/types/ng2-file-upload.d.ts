import * as i0 from '@angular/core';
import { EventEmitter, ElementRef } from '@angular/core';
import * as i3 from '@angular/common';

declare class FileLikeObject {
    lastModifiedDate: any;
    size: any;
    type?: string;
    name?: string;
    rawFile: HTMLInputElement | File;
    constructor(fileOrInput: HTMLInputElement | File);
    _createFromFakePath(path: string): void;
    _createFromObject(object: {
        size: number;
        type: string;
        name: string;
    }): void;
}

declare class FileItem {
    file: FileLikeObject;
    _file: File;
    alias?: string;
    url: string;
    method?: string;
    headers: any;
    withCredentials: boolean;
    formData: any;
    isReady: boolean;
    isUploading: boolean;
    isUploaded: boolean;
    isSuccess: boolean;
    isCancel: boolean;
    isError: boolean;
    progress: number;
    index?: number;
    _xhr?: XMLHttpRequest;
    _form: any;
    protected uploader: FileUploader;
    protected some: File;
    protected options: FileUploaderOptions;
    constructor(uploader: FileUploader, some: File, options: FileUploaderOptions);
    upload(): void;
    cancel(): void;
    remove(): void;
    onBeforeUpload(): void;
    onBuildForm(form: any): any;
    onProgress(progress: number): any;
    onSuccess(response: string, status: number, headers: ParsedResponseHeaders): any;
    onError(response: string, status: number, headers: ParsedResponseHeaders): any;
    onCancel(response: string, status: number, headers: ParsedResponseHeaders): any;
    onComplete(response: string, status: number, headers: ParsedResponseHeaders): any;
    _onBeforeUpload(): void;
    _onBuildForm(form: any): void;
    _onProgress(progress: number): void;
    _onSuccess(response: string, status: number, headers: ParsedResponseHeaders): void;
    _onError(response: string, status: number, headers: ParsedResponseHeaders): void;
    _onCancel(response: string, status: number, headers: ParsedResponseHeaders): void;
    _onComplete(response: string, status: number, headers: ParsedResponseHeaders): void;
    _prepareToUploading(): void;
}

interface Headers {
    name: string;
    value: string;
}
interface ParsedResponseHeaders {
    [headerFieldName: string]: string;
}
interface FilterFunction {
    name: string;
    fn(item: FileLikeObject, options?: FileUploaderOptions): boolean;
}
interface FileUploaderOptions {
    allowedMimeType?: string[];
    allowedFileType?: string[];
    autoUpload?: boolean;
    isHTML5?: boolean;
    filters?: FilterFunction[];
    headers?: Headers[];
    method?: string;
    authToken?: string;
    maxFileSize?: number;
    queueLimit?: number;
    removeAfterUpload?: boolean;
    url: string;
    disableMultipart?: boolean;
    itemAlias?: string;
    authTokenHeader?: string;
    additionalParameter?: {
        [key: string]: any;
    };
    parametersBeforeFiles?: boolean;
    formatDataFunction?: Function;
    formatDataFunctionIsAsync?: boolean;
}
declare class FileUploader {
    authToken?: string;
    isUploading: boolean;
    queue: FileItem[];
    progress: number;
    _nextIndex: number;
    autoUpload: any;
    authTokenHeader?: string;
    response: EventEmitter<any>;
    options: FileUploaderOptions;
    protected _failFilterIndex?: number;
    constructor(options: FileUploaderOptions);
    setOptions(options: FileUploaderOptions): void;
    addToQueue(files: File[], _options?: FileUploaderOptions, filters?: [] | string): void;
    removeFromQueue(value: FileItem): void;
    clearQueue(): void;
    uploadItem(value: FileItem): void;
    cancelItem(value: FileItem): void;
    uploadAll(): void;
    cancelAll(): void;
    isFile(value: any): boolean;
    isFileLikeObject(value: any): boolean;
    getIndexOfItem(value: any): number;
    getNotUploadedItems(): any[];
    getReadyItems(): any[];
    onAfterAddingAll(fileItems: any): any;
    onBuildItemForm(fileItem: FileItem, form: any): any;
    onAfterAddingFile(fileItem: FileItem): any;
    onWhenAddingFileFailed(item: FileLikeObject, filter: any, options: any): any;
    onBeforeUploadItem(fileItem: FileItem): any;
    onProgressItem(fileItem: FileItem, progress: any): any;
    onProgressAll(progress: any): any;
    onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any;
    onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any;
    onCancelItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any;
    onCompleteItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any;
    onCompleteAll(): any;
    _mimeTypeFilter(item: FileLikeObject): boolean;
    _fileSizeFilter(item: FileLikeObject): boolean;
    _fileTypeFilter(item: FileLikeObject): boolean;
    _onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): void;
    _onCompleteItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): void;
    protected _headersGetter(parsedHeaders: ParsedResponseHeaders): any;
    protected _xhrTransport(item: FileItem): any;
    protected _getTotalProgress(value?: number): number;
    protected _getFilters(filters?: FilterFunction[] | string): FilterFunction[] | [];
    protected _render(): any;
    protected _queueLimitFilter(): boolean;
    protected _isValidFile(file: FileLikeObject, filters: FilterFunction[], options: FileUploaderOptions): boolean;
    protected _isSuccessCode(status: number): boolean;
    protected _transformResponse(response: string): string;
    protected _parseHeaders(headers: string): ParsedResponseHeaders;
    protected _onWhenAddingFileFailed(item: FileLikeObject, filter: any, options: any): void;
    protected _onAfterAddingFile(item: FileItem): void;
    protected _onAfterAddingAll(items: any): void;
    protected _onBeforeUploadItem(item: FileItem): void;
    protected _onBuildItemForm(item: FileItem, form: any): void;
    protected _onProgressItem(item: FileItem, progress: any): void;
    protected _onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): void;
    protected _onCancelItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): void;
}

declare class FileDropDirective {
    uploader?: FileUploader;
    fileOver: EventEmitter<any>;
    onFileDrop: EventEmitter<File[]>;
    protected element: ElementRef;
    getOptions(): FileUploaderOptions | void;
    getFilters(): string;
    onDrop(event: MouseEvent): void;
    onDragOver(event: MouseEvent): void;
    onDragLeave(event: MouseEvent): void;
    protected _getTransfer(event: any): any;
    protected _preventAndStop(event: MouseEvent): void;
    protected _haveFiles(types: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDropDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FileDropDirective, "[ng2FileDrop]", never, { "uploader": { "alias": "uploader"; "required": false; }; }, { "fileOver": "fileOver"; "onFileDrop": "onFileDrop"; }, never, never, false, never>;
}

declare class FileSelectDirective {
    uploader?: FileUploader;
    onFileSelected: EventEmitter<File[]>;
    protected element: ElementRef;
    getOptions(): FileUploaderOptions | undefined;
    getFilters(): string;
    isEmptyAfterSelection(): boolean;
    onChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSelectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FileSelectDirective, "[ng2FileSelect]", never, { "uploader": { "alias": "uploader"; "required": false; }; }, { "onFileSelected": "onFileSelected"; }, never, never, false, never>;
}

declare class FileUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FileUploadModule, [typeof FileDropDirective, typeof FileSelectDirective], [typeof i3.CommonModule], [typeof FileDropDirective, typeof FileSelectDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FileUploadModule>;
}

export { FileDropDirective, FileItem, FileLikeObject, FileSelectDirective, FileUploadModule, FileUploader };
export type { FileUploaderOptions, FilterFunction, Headers, ParsedResponseHeaders };
